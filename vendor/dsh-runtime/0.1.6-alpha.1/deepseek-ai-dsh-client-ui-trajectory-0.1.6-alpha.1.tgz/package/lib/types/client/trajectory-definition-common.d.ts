import type { ConversationNodeContext } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { TrajectoryContribution, TrajectoryConversationViewNode } from './trajectory-contract.ts';
/**
 * Wrap one contribution in the Engine-owned target envelope.
 *
 * @param context - Context that owns the contribution identity.
 * @param anchorSeq - Sequence used to order the contribution.
 * @param data - Trajectory-specific contribution payload.
 * @returns The contribution wrapped as a Trajectory view node.
 */
export declare function trajectoryNode(context: ConversationNodeContext, anchorSeq: number, data: TrajectoryContribution): TrajectoryConversationViewNode;
//# sourceMappingURL=trajectory-definition-common.d.ts.map